<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento de Extensão de Cílios</title>
    <link href="../view_css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="view_css/estilo.css">
    <link rel="shortcut icon" href="" type="image/png">
</head>
<body>

    <div class="container">
        <h1>Agende seu Atendimento de Extensão de Cílios</h1>

        <form id="appointmentForm">
            <label for="name">Seu Nome:</label>
            <input type="text" id="name" name="name" required placeholder="Digite seu nome completo">

            <label for="service">Escolha o Serviço:</label>
            <select id="service" name="service" required>
                <option value="volume">Volume Russo</option>
                <option value="natural">Natural</option>
                <option value="alongamento">Alongamento Clássico</option>
            </select>

            <label for="date">Escolha a Data:</label>
            <input type="date" id="date" name="date" required>

            <label for="time">Escolha o Horário:</label>
            <input type="time" id="time" name="time" required>

            <button type="submit">Agendar</button>
        </form>

        <div id="successMessage" class="message" style="display: none;">
            Agendamento realizado com sucesso! Aguarde nossa confirmação.
        </div>
    </div>

    <script>
        document.getElementById("appointmentForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Previne o envio padrão do formulário

            // Captura os valores dos campos
            var nome = document.getElementById("name").value;
            var service = document.getElementById("service").value;
            var date = document.getElementById("date").value;
            var time = document.getElementById("time").value;

            if (name && service && date && time) {
                // Exibe uma mensagem de sucesso
                document.getElementById("successMessage").style.display = "block";

                // Limpa os campos após o agendamento
                document.getElementById("appointmentForm").reset();
            } else {
                alert("Por favor, preencha todos os campos.");
            }
        });
    </script>

</body>
</html>

<!DOCTYPE html>
<html lang="pt_br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../view_css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="view_css/estilo.css">
    
    
    <title>Home | JM BEAUTY</title>
</head>



<nav>
<button> <a href="#home">Home</a> </button>
<button> <a href="#servicos">Serviços</a> </button>
<button> <a href="#sobre">Sobre</a> </button>
<button> <a href="#cursos">Cursos</a> </button>
<button> <a href="#contato">Contato</a> </button>
</nav>